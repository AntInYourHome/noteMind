"""
NoteMind 导入核心逻辑 — 库化 API，供 CLI 和 GUI 复用
"""

import logging
import os
from datetime import datetime
from pathlib import Path

from scripts.metrics import MetricsCollector

logger = logging.getLogger("notemind")


class NoteMindImporter:
    """导入引擎：处理文件批量导入。"""

    def __init__(self, config: dict, progress_callback=None):
        """
        Args:
            config: 配置 dict（同 config.json 格式）
            progress_callback: 可选回调 fn(event: dict)，用于 GUI 进度更新
        """
        self.config = config
        self.progress_callback = progress_callback
        self._cancelled = False
        self.metrics = MetricsCollector(
            log_dir=config.get("logging", {}).get("log_dir", "logs")
        )

    def cancel(self):
        """取消当前导入。"""
        self._cancelled = True

    def _emit(self, event: dict):
        """发送进度事件。"""
        if self.progress_callback:
            self.progress_callback(event)

    def run(self, source: str, vault_path: str, resume: bool = False, dry_run: bool = False) -> dict:
        """执行导入流程。

        Args:
            source: 源文件目录
            vault_path: Vault 目录
            resume: 是否从检查点恢复
            dry_run: 预览模式

        Returns:
            最终统计 {"ok": int, "failed": int, "skipped": int, "elapsed": float}
        """
        from importlib import import_module

        # 动态导入依赖（避免 GUI 启动时加载所有依赖）
        import_mod = import_module("import")
        collect_files = import_mod.collect_files
        handle_file = import_mod.handle_file
        move_to_failed = import_mod.move_to_failed
        update_moc = import_mod.update_moc

        source = os.path.realpath(source)
        vault_path = os.path.expanduser(vault_path)

        if not os.path.isdir(source):
            self._emit({"type": "error", "message": f"源目录不存在: {source}"})
            return {"ok": 0, "failed": 0, "skipped": 0}

        # 初始化 Vault
        import_mod.init_vault(vault_path)

        # 设置 API Key
        if self.config.get("ai", {}).get("api_key"):
            os.environ["QWEN_API_KEY"] = self.config["ai"]["api_key"]

        # 收集文件
        files = collect_files(source)
        if not files:
            self._emit({"type": "error", "message": "未找到可处理的文件"})
            return {"ok": 0, "failed": 0, "skipped": 0}

        stats = {"ok": 0, "failed": 0, "skipped": 0}

        # 检查点恢复
        processed_set = set()
        if resume:
            log_dir = self.config.get("logging", {}).get("log_dir", "logs")
            checkpoint = MetricsCollector.load_checkpoint(log_dir, logger=logger)
            if checkpoint and os.path.realpath(checkpoint["source"]) == source:
                processed_set = set(checkpoint["processed"])
                restored = checkpoint["metrics"]
                self.metrics.metrics = restored
                self.metrics.metrics["run_id"] = datetime.now().strftime("%Y%m%d_%H%M%S")
                self._emit({"type": "resume", "count": len(processed_set),
                           "ok": restored["succeeded"], "failed": restored["failed"]})
            else:
                self._emit({"type": "resume_miss"})

        # MD5 去重
        if self.config["import"].get("dedup", True):
            from scripts.dedup import check_duplicate
            dedup_index = self.config["import"].get("dedup_index", ".notemind_index.json")
            unique_files = []
            for f in files:
                dup = check_duplicate(f, vault_path, dedup_index)
                if dup:
                    stats["skipped"] += 1
                    self.metrics.end_file("skip", "重复文件")
                    self._emit({"type": "file_skip", "file": os.path.basename(f), "reason": "duplicate"})
                else:
                    unique_files.append(f)
            files = unique_files
            if not files:
                self._emit({"type": "all_duplicate"})
                return stats

        # 过滤已处理文件
        if resume and processed_set:
            files = [f for f in files if f not in processed_set]

        total = len(files)
        self.metrics.set_total(total)
        self._emit({"type": "start", "total": total, "source": source})

        for i, file_path in enumerate(files, 1):
            if self._cancelled:
                self._emit({"type": "cancelled", "processed": i - 1, "total": total})
                break

            fname = os.path.basename(file_path)
            self._emit({"type": "file_start", "index": i, "total": total, "file": fname})

            if dry_run:
                stats["skipped"] += 1
                self._emit({"type": "file_skip", "file": fname, "reason": "dry_run"})
                continue

            self.metrics.start_file(file_path)

            try:
                result = handle_file(file_path, self.config, vault_path)
            except Exception as e:
                result = {"status": "fail", "error": f"{type(e).__name__}: {e}"}
                logger.exception(f"  [EXCEPTION] {fname}: {e}")

            if result["status"] == "ok":
                stats["ok"] += 1
                self.metrics.end_file("ok", result.get("category", ""))
                self._emit({"type": "file_ok", "index": i, "file": fname,
                           "category": result.get("category", ""),
                           "tags": result.get("tags", []),
                           "path": result.get("path", "")})
            else:
                stats["failed"] += 1
                self.metrics.end_file("fail", result.get("error", ""))
                move_to_failed(file_path, vault_path,
                              self.config["import"]["failed_dir"],
                              result.get("error", ""))
                self._emit({"type": "file_fail", "index": i, "file": fname,
                           "error": result.get("error", "")})

            self.metrics.log_progress(logger, interval=10)

            # 保存检查点
            if not dry_run:
                self.metrics.save_checkpoint(source, files,
                    set(m["file"] for m in self.metrics.metrics["file_details"]))

        # 完成
        health = self.metrics.get_health()
        self._emit({"type": "health", "healthy": health["healthy"], "message": health["message"]})

        if not dry_run and not self._cancelled:
            try:
                update_moc(vault_path)
                MetricsCollector.clear_checkpoint(
                    self.config.get("logging", {}).get("log_dir", "logs")
                )
            except Exception as e:
                logger.error(f"更新 MOC 失败: {e}")

        try:
            report_path = self.metrics.save_report()
            self._emit({"type": "report", "path": report_path})
        except Exception:
            pass

        self._emit({"type": "complete", **stats,
                   "elapsed": self.metrics.get_progress()["elapsed"]})

        self.metrics.print_summary(logger)
        return stats
