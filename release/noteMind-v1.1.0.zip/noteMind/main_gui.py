#!/usr/bin/env python3
"""
NoteMind GUI 启动入口
用法：python main_gui.py
"""

import sys


def main():
    if sys.version_info < (3, 10):
        print("NoteMind 需要 Python 3.10+")
        sys.exit(1)

    try:
        import tkinter
    except ImportError:
        print("tkinter 不可用，请安装 python3-tk 或使用完整版 Python")
        sys.exit(1)

    from gui.app import NoteMindApp
    app = NoteMindApp()
    app.mainloop()


if __name__ == "__main__":
    main()
