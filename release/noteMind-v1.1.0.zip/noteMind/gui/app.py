"""
NoteMind GUI 主窗口 — tkinter 构建的非技术用户友好界面
"""

import os
import queue
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from pathlib import Path

from gui.settings import (
    load_gui_config, save_gui_config, import_cli_config, build_notemind_config,
)
from gui.worker import ImportWorker


class NoteMindApp(tk.Tk):
    """NoteMind 桌面应用主窗口。"""

    def __init__(self):
        super().__init__()
        self.title("NoteMind — 文件导入工具")
        self.geometry("720x620")
        self.minsize(600, 500)

        self._event_queue = queue.Queue()
        self.worker = None
        self.running = False

        # 加载配置
        self.gui_cfg = load_gui_config()

        # 首次启动：尝试导入 CLI 配置
        if not self.gui_cfg["api_key"]:
            cli_cfg = import_cli_config()
            if cli_cfg:
                self.gui_cfg.update(cli_cfg)
                save_gui_config(self.gui_cfg)

        self._build_ui()
        self._load_settings()

        # 定时检查事件队列
        self.after(100, self._check_events)

    def _build_ui(self):
        """构建界面布局。"""
        # --- 输入区域 ---
        input_frame = ttk.LabelFrame(self, text="基本设置", padding=10)
        input_frame.pack(fill=tk.X, padx=10, pady=5)

        # 源文件目录
        row1 = ttk.Frame(input_frame)
        row1.pack(fill=tk.X, pady=3)
        ttk.Label(row1, text="源文件目录:", width=12).pack(side=tk.LEFT)
        self.source_var = tk.StringVar()
        ttk.Entry(row1, textvariable=self.source_var).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        ttk.Button(row1, text="浏览...", command=self._browse_source).pack(side=tk.RIGHT)

        # Vault 目录
        row2 = ttk.Frame(input_frame)
        row2.pack(fill=tk.X, pady=3)
        ttk.Label(row2, text="Vault 目录:", width=12).pack(side=tk.LEFT)
        self.vault_var = tk.StringVar()
        ttk.Entry(row2, textvariable=self.vault_var).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        ttk.Button(row2, text="浏览...", command=self._browse_vault).pack(side=tk.RIGHT)

        # API Key
        row3 = ttk.Frame(input_frame)
        row3.pack(fill=tk.X, pady=3)
        ttk.Label(row3, text="API Key:", width=12).pack(side=tk.LEFT)
        self.api_var = tk.StringVar()
        ttk.Entry(row3, textvariable=self.api_var, show="*").pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        ttk.Button(row3, text="测试", command=self._test_api).pack(side=tk.RIGHT)

        # 分类
        row4 = ttk.Frame(input_frame)
        row4.pack(fill=tk.X, pady=3)
        ttk.Label(row4, text="分类:", width=12).pack(side=tk.LEFT)
        self.cat_var = tk.StringVar(value="")
        ttk.Entry(row4, textvariable=self.cat_var).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        ttk.Button(row4, text="编辑...", command=self._edit_categories).pack(side=tk.RIGHT)

        # --- 控制按钮 ---
        ctrl_frame = ttk.Frame(self, padding=10)
        ctrl_frame.pack(fill=tk.X, padx=10)

        self.start_btn = ttk.Button(ctrl_frame, text="开始导入", command=self._start_import)
        self.start_btn.pack(side=tk.LEFT, padx=5)

        self.cancel_btn = ttk.Button(ctrl_frame, text="取消", command=self._cancel_import, state=tk.DISABLED)
        self.cancel_btn.pack(side=tk.LEFT, padx=5)

        ttk.Button(ctrl_frame, text="保存设置", command=self._save_settings).pack(side=tk.RIGHT, padx=5)

        # --- 进度条 ---
        progress_frame = ttk.LabelFrame(self, text="进度", padding=10)
        progress_frame.pack(fill=tk.X, padx=10, pady=5)

        self.progress = ttk.Progressbar(progress_frame, mode="determinate")
        self.progress.pack(fill=tk.X, pady=3)

        self.status_var = tk.StringVar(value="就绪")
        ttk.Label(progress_frame, textvariable=self.status_var).pack(fill=tk.X)

        self.stats_var = tk.StringVar(value="成功: 0  失败: 0  跳过: 0")
        ttk.Label(progress_frame, textvariable=self.stats_var).pack(fill=tk.X)

        # --- 日志区域 ---
        log_frame = ttk.LabelFrame(self, text="日志", padding=5)
        log_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        self.log_text = tk.Text(log_frame, height=10, state=tk.DISABLED, font=("Courier", 9))
        scrollbar = ttk.Scrollbar(log_frame, orient=tk.VERTICAL, command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    def _load_settings(self):
        """从配置加载到 UI。"""
        self.source_var.set(self.gui_cfg.get("last_source", ""))
        self.vault_var.set(self.gui_cfg.get("vault_path", ""))
        self.api_var.set(self.gui_cfg.get("api_key", ""))
        cats = self.gui_cfg.get("categories", [])
        self.cat_var.set(", ".join(cats))

    def _save_settings(self):
        """保存 UI 设置到配置文件。"""
        cats = [c.strip() for c in self.cat_var.get().split(",") if c.strip()]
        self.gui_cfg.update({
            "api_key": self.api_var.get().strip(),
            "vault_path": self.vault_var.get().strip(),
            "categories": cats,
            "last_source": self.source_var.get().strip(),
        })
        save_gui_config(self.gui_cfg)
        self._log("设置已保存")
        messagebox.showinfo("保存", "设置已保存")

    def _browse_source(self):
        path = filedialog.askdirectory(title="选择源文件目录")
        if path:
            self.source_var.set(path)

    def _browse_vault(self):
        path = filedialog.askdirectory(title="选择 Vault 目录")
        if path:
            self.vault_var.set(path)

    def _test_api(self):
        """测试 API 连接。"""
        api_key = self.api_var.get().strip()
        if not api_key:
            messagebox.showwarning("提示", "请先输入 API Key")
            return
        self._log("测试 API 连接...")
        try:
            import urllib.request
            import urllib.error
            import json
            req = urllib.request.Request(
                "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
                data=json.dumps({
                    "model": "qwen3.6-flash",
                    "messages": [{"role": "user", "content": "你好"}],
                    "max_tokens": 10,
                }).encode(),
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {api_key}",
                },
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                resp.read()
            self._log("API 连接成功！")
            messagebox.showinfo("成功", "API 连接正常")
        except Exception as e:
            self._log(f"API 连接失败: {e}")
            messagebox.showerror("失败", f"API 连接失败:\n{e}")

    def _edit_categories(self):
        """编辑分类列表。"""
        current = self.cat_var.get()
        dialog = tk.Toplevel(self)
        dialog.title("编辑分类")
        dialog.geometry("350x200")
        ttk.Label(dialog, text="用逗号分隔分类名称:").pack(padx=10, pady=5)
        entry = ttk.Entry(dialog, width=40)
        entry.pack(padx=10, fill=tk.X)
        entry.insert(0, current)

        def save():
            self.cat_var.set(entry.get())
            dialog.destroy()

        ttk.Button(dialog, text="确定", command=save).pack(pady=10)
        entry.focus()
        self.wait_window(dialog)

    def _log(self, message: str):
        """追加日志消息。"""
        self.log_text.configure(state=tk.NORMAL)
        self.log_text.insert(tk.END, f"{message}\n")
        self.log_text.see(tk.END)
        self.log_text.configure(state=tk.DISABLED)

    def _check_events(self):
        """定时检查后台事件队列。"""
        try:
            while True:
                event = self._event_queue.get_nowait()
                self._handle_event(event)
        except queue.Empty:
            pass
        self.after(100, self._check_events)

    def _handle_event(self, event: dict):
        """处理导入事件，更新 UI。"""
        t = event.get("type", "")

        if t == "start":
            self.running = True
            self.start_btn.configure(state=tk.DISABLED)
            self.cancel_btn.configure(state=tk.NORMAL)
            self.progress["maximum"] = event["total"]
            self.progress["value"] = 0
            self.status_var.set(f"共 {event['total']} 个文件，开始处理...")
            self._log(f"开始导入: {event['total']} 个文件")

        elif t == "resume":
            self._log(f"从检查点恢复: 已处理 {event['count']} 个文件 (成功 {event['ok']}, 失败 {event['failed']})")

        elif t == "resume_miss":
            self._log("未找到匹配的检查点，从头开始")

        elif t == "file_start":
            self.status_var.set(f"[{event['index']}/{event['total']}] {event['file']}")
            self._log(f"处理: {event['file']}")

        elif t == "file_ok":
            self.progress.step(1)
            self._log(f"  [OK] {event['file']} → {event.get('category', '?')}")

        elif t == "file_fail":
            self.progress.step(1)
            self._log(f"  [FAIL] {event['file']}: {event['error']}")

        elif t == "file_skip":
            self._log(f"  [SKIP] {event['file']}: {event['reason']}")

        elif t == "error":
            self._log(f"  [ERROR] {event['message']}")
            messagebox.showerror("错误", event["message"])

        elif t == "all_duplicate":
            self._log("所有文件均为重复文件，无需处理")
            self._set_idle()

        elif t == "complete":
            self._set_idle()
            ok = event.get("ok", 0)
            failed = event.get("failed", 0)
            skipped = event.get("skipped", 0)
            elapsed = event.get("elapsed", 0)
            self.stats_var.set(f"成功: {ok}  失败: {failed}  跳过: {skipped}")
            self._log(f"完成! 成功: {ok}, 失败: {failed}, 跳过: {skipped}, 耗时: {elapsed:.1f}s")
            messagebox.showinfo("完成", f"导入完成!\n成功: {ok}\n失败: {failed}\n跳过: {skipped}\n耗时: {elapsed:.1f}s")

        elif t == "cancelled":
            self._set_idle()
            self._log(f"已取消，已处理 {event['processed']}/{event['total']} 个文件")
            messagebox.showinfo("已取消", f"导入已取消\n已处理: {event['processed']}/{event['total']}")

        elif t == "report":
            self._log(f"报告已保存: {event['path']}")

    def _set_idle(self):
        """恢复空闲状态。"""
        self.running = False
        self.start_btn.configure(state=tk.NORMAL)
        self.cancel_btn.configure(state=tk.DISABLED)
        self.status_var.set("就绪")

    def _start_import(self):
        """开始导入。"""
        api_key = self.api_var.get().strip()
        source = self.source_var.get().strip()
        vault = self.vault_var.get().strip()

        if not api_key:
            messagebox.showwarning("提示", "请先输入 API Key")
            return
        if not source:
            messagebox.showwarning("提示", "请选择源文件目录")
            return
        if not vault:
            messagebox.showwarning("提示", "请选择 Vault 目录")
            return

        # 构建配置
        cfg = build_notemind_config(self.gui_cfg)

        self.worker = ImportWorker(cfg, on_event=self._event_queue.put)
        self._log("启动导入任务...")
        self.worker.start(source, vault, resume=True)

    def _cancel_import(self):
        """取消导入。"""
        if self.worker and self.worker.is_alive():
            if messagebox.askyesno("确认", "确定要取消导入吗？"):
                self.worker.cancel()
                self._log("正在取消...")
