"""
NoteMind GUI 配置管理 — 持久化用户设置，自动导入 CLI 配置
"""

import json
import os
from pathlib import Path

GUI_CONFIG_PATH = Path.home() / ".notemind_gui_config.json"

DEFAULT_CONFIG = {
    "api_key": "",
    "model": "qwen3.6-flash",
    "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
    "vault_path": str(Path.home() / "knowledge-base"),
    "categories": ["芯片", "安全", "项目", "笔记", "其他"],
    "last_source": "",
    "max_retries": 3,
    "retry_delay": 2,
    "dedup": True,
    "log_level": "INFO",
}


def load_gui_config() -> dict:
    """加载 GUI 配置，合并默认值。"""
    cfg = DEFAULT_CONFIG.copy()
    if GUI_CONFIG_PATH.exists():
        try:
            with open(GUI_CONFIG_PATH, "r", encoding="utf-8") as f:
                user_cfg = json.load(f)
                cfg.update(user_cfg)
        except Exception:
            pass
    return cfg


def save_gui_config(cfg: dict):
    """保存 GUI 配置。"""
    with open(GUI_CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def import_cli_config(cli_config_path: str = None) -> dict | None:
    """尝试从 CLI config.json 导入配置。

    Returns:
        配置 dict 或 None（文件不存在/无效）
    """
    if cli_config_path is None:
        # 尝试在脚本同级目录查找
        cli_config_path = Path(__file__).parent.parent / "config.json"
    cli_config_path = Path(cli_config_path)
    if not cli_config_path.exists():
        return None

    try:
        with open(cli_config_path, "r", encoding="utf-8") as f:
            raw = json.load(f)
    except Exception:
        return None

    result = DEFAULT_CONFIG.copy()
    ai = raw.get("ai", {})
    vault = raw.get("vault", {})
    imp = raw.get("import", {})
    log = raw.get("logging", {})

    result["api_key"] = ai.get("api_key", "")
    result["model"] = ai.get("model", "qwen3.6-flash")
    result["base_url"] = ai.get("base_url", DEFAULT_CONFIG["base_url"])
    result["vault_path"] = os.path.expanduser(vault.get("path", DEFAULT_CONFIG["vault_path"]))
    result["categories"] = vault.get("categories", DEFAULT_CONFIG["categories"])
    result["max_retries"] = imp.get("max_retries", 3)
    result["retry_delay"] = imp.get("retry_delay", 2)
    result["dedup"] = imp.get("dedup", True)
    result["log_level"] = log.get("level", "INFO")

    return result


def build_notemind_config(gui_cfg: dict) -> dict:
    """将 GUI 配置转换为 NoteMind 内部配置格式（同 config.json）。"""
    return {
        "ai": {
            "api_key": gui_cfg["api_key"],
            "model": gui_cfg.get("model", "qwen3.6-flash"),
            "base_url": gui_cfg.get("base_url", DEFAULT_CONFIG["base_url"]),
        },
        "vault": {
            "path": os.path.expanduser(gui_cfg["vault_path"]),
            "categories": gui_cfg.get("categories", DEFAULT_CONFIG["categories"]),
        },
        "import": {
            "archive_dir": "_archive",
            "failed_dir": "_failed",
            "max_retries": gui_cfg.get("max_retries", 3),
            "retry_delay": gui_cfg.get("retry_delay", 2),
            "dedup": gui_cfg.get("dedup", True),
            "dedup_index": ".notemind_index.json",
        },
        "logging": {
            "level": gui_cfg.get("log_level", "INFO"),
            "file": "logs/import.log",
            "log_dir": "logs",
        },
    }
