"""
NoteMind GUI 后台工作线程 — 安全更新 UI 的导入任务
"""

import queue
import threading


class ImportWorker:
    """在后台线程运行 NoteMind 导入，通过事件队列通知主线程。"""

    def __init__(self, config: dict, on_event):
        """
        Args:
            config: NoteMind 配置 dict
            on_event: 主线程回调 fn(event: dict)，通过 queue 安全调用
        """
        self.config = config
        self.on_event = on_event
        self.importer = None
        self._thread = None

    def start(self, source: str, vault_path: str, resume: bool = False, dry_run: bool = False):
        """启动后台导入。"""
        from scripts.importer import NoteMindImporter

        self.importer = NoteMindImporter(self.config, progress_callback=self.on_event)
        self._thread = threading.Thread(
            target=self._run,
            args=(source, vault_path, resume, dry_run),
            daemon=True,
        )
        self._thread.start()

    def _run(self, source, vault_path, resume, dry_run):
        try:
            self.importer.run(source, vault_path, resume, dry_run)
        except Exception as e:
            self.on_event({"type": "error", "message": str(e)})

    def cancel(self):
        """取消当前导入。"""
        if self.importer:
            self.importer.cancel()

    def is_alive(self) -> bool:
        return self._thread is not None and self._thread.is_alive()
